// Surname: Bandarkar
// Name: Mohamed Asad
// Student no: 4271451
// Course: CSC211
// Year: 2023
// Assignment: Practical 1 Term 2
// File: Playlist.java

class Playlist{

    /* attributes */
    private Track root; // root of the playlist
    private int size; // number of tracks in the playlist

    //Default Constructor
    Playlist(){
        root = null;       //root is empty
        size = 0;          //size is 0
    }

    //Getter methods
    public Track getRoot() {
        return root;
    }

    public int getSize() {
        return size;
    }

    //Setter Methods
    public void setRoot(Track root) {
        this.root = root;
    }

    public void setSize(int size) {
        this.size = size;
    }


    /* methods */
    void clear(){         //makes the tree empty and resets the size
        root = null;
        size = 0;
    }

    public Boolean search(String title){
        return searchHelper(root , title);   //searches for the node with the specified title using the searchHelper method
    }

    private boolean searchHelper(Track node, String title){
        if(node == null){                                       //if node is empty
            return false;
        } else if (node.getTitle().compareTo(title) > 0) {      //checking if the title is less than the current node's title
            return searchHelper(node.getLeft(), title);         //if less, the method calls itself recursively with the node's left child and the title parameter
        } else {
            return searchHelper(node.getRight(), title);        //if greater or equal, the method calls itself recursively with the node's right child and the title parameter
        }

    }

    void insert(String id,String title, String artist, String album, int minutes,int seconds){
        Track track = new Track(id,title, artist, album , minutes, seconds);  //inserting a track into playlist
        root = insertHelper(root, track);                                     //returns the modified root node of the binary search tree after the Track object has been inserted
        size++;                                                               //increment the size
    }

    private Track insertHelper(Track node,Track newTrack){
        if(node == null){       //if root node is empty
            node = newTrack;    //assign track to node
            return node;        //then return that node

        } else if (node.getTitle().compareTo(newTrack.getTitle()) > 0) {    //comparing title of track being inserted to current node.If the title of the newTrack is less than the title of the node,
            node.setLeft(insertHelper(node.getLeft(), newTrack));           // then the newTrack is inserted into the left subtree of the node

        } else {
            node.setRight(insertHelper(node.getRight(), newTrack));         //if the title of the newTrack is greater than or equal to the title of the node,
                                                                            //then the newTrack is inserted into the right subtree of the node
        }
        return node;                                                        //return current node
    }


    void delete(String title){
        root = deleteHelper(root, title);                            //root node is updated with the return value of deleteHelper. It is then stored in root
        size--;                                                      //decrement the size
    }

    private Track deleteHelper(Track node, String title) {
        if (node == null) {                                        //checking if node is empty
            return node;
        }
        if (node.getTitle().compareTo(title) > 0) {                //if title of the input node is greater than the specified title,
            node.setLeft(deleteHelper(node.getLeft(), title));     //then recursively call deleteHelper method on the left child of the input node with the same title
        } else if (node.getTitle().compareTo(title) < 0) {         //If the title of the input node is less than the specified title
            node.setRight(deleteHelper(node.getRight(), title));   //then recursively call the deleteHelper method on the right child of the input node with the same title
        }
        return node;                                               //return the node
    }

    void displayInOrder(Track t){
        if (t == null) {         //if track t is empty
            return;
        }
        displayInOrder(t.getLeft());         //inorder traversal using toString method
        System.out.println(t.toString());    //inorder traversal ---> left,root,right
        displayInOrder(t.getRight());

    }

    int height(Track t){
        if (t == null) {
            return -1;                                 //represents empty tree
        } else {
            int leftHeight = height(t.getLeft());     //height of left subtree
            int rightHeight = height(t.getRight());   //height of right subtree
            return 1 + Math.max(leftHeight, rightHeight);  //the maximum height between leftHeight & rightHeight + 1 = height of playlist
        }

    }

}